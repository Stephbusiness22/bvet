<!DOCTYPE html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>BVET-CI</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!-- Favicon -->
    <link
      rel="shortcut icon"
      type="image/x-icon"
      href="assets/img/favicon.png"
    />

    <!-- all css here -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/magnific-popup.css" />
    <link rel="stylesheet" href="assets/css/animate.css" />
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="assets/css/themify-icons.css" />
    <link rel="stylesheet" href="assets/css/pe-icon-7-stroke.css" />
    <link rel="stylesheet" href="assets/css/meanmenu.min.css" />
    <link rel="stylesheet" href="assets/css/bundle.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/responsive.css" />
    <script src="assets/js/vendor/modernizr-3.11.7.min.js"></script>
  </head>

  <body>
    <!--[if lt IE 8]>
      <p class="browserupgrade">
        You are using an <strong>outdated</strong> browser. Please
        <a href="https://browsehappy.com/">upgrade your browser</a> to improve
        your experience.
      </p>
    <![endif]-->
    <!-- header start -->

    <header>
      <div class="header-area">
        <div class="header-left-sidebar">
          <div class="logo">
            <a href="index.php"
              ><img src="assets/img/logo/logo.png" alt=""
            /></a>
          </div>

          <div class="main-menu menu-hover">
            <nav>
              <ul>
                <li><a href="index.php">ACCUEIL</a></li>
                <li>
                  <a href="#">TELECOMMUNICATION</a>
                  <ul class="single-dropdown">
                    <li>
                      <a href="#">Wifi</a>
                      <ul class="single-dropdown">
                        <li><a href="liaison_radio.php">Liaison radio</a></li>
                        <li><a href="bouclier_rf.php">Bouclier RF</a></li>
                        <li>
                          <a href="accessoire_faiwifi.php"
                            >Accessoire FAI WIFI</a
                          >
                        </li>
                      </ul>
                    </li>

                    <li>
                      <a href="#">Fibre optique</a>
                      <ul class="single-dropdown">
                        <li><a href="gpon.php">GPON</a></li>
                        <li><a href="epon.php">EPON</a></li>
                        <li><a href="fusionneuse.php">Fusionneuse</a></li>
                        <li>
                          <a href="boite_d_f.php"
                            >Boiter de distribution de fibre</a
                          >
                        </li>
                        <li><a href="separateur.php">Separateurs</a></li>
                        <li><a href="cable.php">Cable</a></li>
                      </ul>
                    </li>

                    <li><a href="racks_externe.php">Racks exterieurs</a></li>

                    <li><a href="panneaux.php">Panneaux</a></li>

                    <li><a href="refrigelation.php">Refrigélation</a></li>

                    <li><a href="plateaux.php">Plateaux</a></li>

                    <li>
                      <a href="#">Outils</a>
                      <ul class="single-dropdown">
                        <li><a href="etiqueteuse.php">Etiqueteuse</a></li>
                        <li>
                          <a href="malette_outils.php">Malette à outil</a>
                        </li>
                        <li><a href="sertisseuse.php">Sertisseuses</a></li>
                      </ul>
                    </li>
                  </ul>
                </li>

                <li>
                  <a href="#">RESEAUX</a>
                  <ul class="single-dropdown">
                    <li>
                      <a href="#">Ethernet</a>
                      <ul class="single-dropdown">
                        <li><a href="routeur.php">Routeurs</a></li>
                        <li><a href="fibre_optique.php">Fibre optique</a></li>
                        <li>
                          <a href="convertisseur.php">Convertisseur moyen</a>
                        </li>
                        <li>
                          <a href="adapteur_reseau.php">Adaptateur réseau</a>
                        </li>
                        <li>
                          <a href="accessoire_ethernet.php"
                            >Accessoires Ethernet</a
                          >
                        </li>
                        <li>
                          <a href="outil_ethernet.php">Outils Ethernet</a>
                        </li>
                      </ul>
                    </li>

                    <li>
                      <a href="#">Wifi</a>
                      <ul class="single-dropdown">
                        <li>
                          <a href="couverture_totale.php">couverture totale</a>
                        </li>
                        <li><a href="point_acces.php">Point d'accès</a></li>
                        <li><a href="controleur_ap.php">Contrleur AP</a></li>
                        <li><a href="repeteur.php">Repéteur</a></li>
                        <li><a href="adaptateur.php">Adaptateur</a></li>
                        <li><a href="routeur_r.php">Routeur</a></li>
                      </ul>
                    </li>

                    <li><a href="menu-list.php">Gestion</a></li>

                    <li>
                      <a href="#">4G-LTE</a>
                      <ul class="single-dropdown">
                        <li><a href="routeur_4g.php">Routeur- 4G LTE</a></li>
                        <li>
                          <a href="rayon_ethernet.php">Rayon Ethernet</a>
                        </li>
                        <li><a href="cpe_ethernet.php">CPE Ethernet</a></li>
                        <li><a href="antenne.php">Antenne</a></li>
                      </ul>
                    </li>
                  </ul>
                </li>

                <li>
                  <a href="#">SECURITE</a>
                  <ul class="single-dropdown">
                    <li>
                      <a href="paratonnere_parafoud.php"
                        >Paratonnere-parafoudre</a
                      >
                    </li>
                  </ul>
                </li>

                <li>
                  <a href="#">ELECTRICITE</a>
                  <ul class="single-dropdown">
                    <li><a href="courant_faible.php">Courant faible</a></li>
                    <li>
                      <a href="paratonnere.php">Paratonnere/parafoudre</a>
                    </li>
                  </ul>
                </li>

                <li>
                  <a href="#">TELEPHONE</a>
                  <ul class="single-dropdown">
                    <li><a href="telephone.php">Téléphone</a></li>
                    <li><a href="tablette.php">Tablette</a></li>
                    <li><a href="passerelle_ata.php">Paserelles ATA</a></li>
                  </ul>
                </li>

                <li>
                  <a href="#">VIDEOSUEVEILLANCE</a>
                  <ul class="single-dropdown">
                    <li>
                      <a href="camera_surveillance.php"
                        >Caméra de surveillance</a
                      >
                    </li>
                    <li>
                      <a href="camera_thermique.php">Caméra thermique</a>
                    </li>
                    <li><a href="camera_ip.php">Caméra IP</a></li>
                    <li>
                      <a href="#">Visioconférence</a>
                      <ul class="single-dropdown">
                        <li>
                          <a href="visioconference.php">Interphones vidéo</a>
                        </li>
                      </ul>
                    </li>
                  </ul>
                </li>

                <li>
                  <a href="#">INFORMATIQUE</a>
                  <ul class="single-dropdown">
                    <li>
                      <a href="armoire_coffret_informatique.php"
                        >Armoire coffret informatique</a
                      >
                    </li>
                    <li><a href="ordinateur.php">Ordinateur</a></li>
                  </ul>
                </li>

                <li><a href="about-us.php">SOCIETE</a></li>

                <li><a href="contact.php">CONTACT</a></li>
              </ul>
            </nav>
          </div>
        </div>
        <div class="header-right-sidebar">
          <div class="header-search-cart-login">
            <div class="logo">
              <a href="index.php">
                <img src="assets/img/logo/logo.png" alt="" />
              </a>
            </div>
            <div class="header-search">
              <form action="#">
                <input placeholder="Search What you want" type="text" />
                <button>
                  <i class="ti-search"></i>
                </button>
              </form>
            </div>
            <div class="header-login">
              <ul>
                <li><a href="login.php">CONNEXION</a></li>
                <li><a href="register.php">S'INSCRIRE</a></li>
              </ul>
            </div>
            <div class="header-cart cart-res">
              <a class="icon-cart" href="cart.php">
                <i class="ti-shopping-cart"></i>
                <span class="shop-count pink">02</span>
              </a>
              <ul class="cart-dropdown">
                <li class="single-product-cart">
                  <div class="cart-img">
                    <a href="#"><img src="assets/img/cart/1.jpg" alt="" /></a>
                  </div>
                  <div class="cart-title">
                    <h5><a href="#"> Bits Headphone</a></h5>
                    <h6><a href="#">Black</a></h6>
                    <span>$80.00 x 1</span>
                  </div>
                  <div class="cart-delete">
                    <a href="#"><i class="ti-trash"></i></a>
                  </div>
                </li>
                <li class="single-product-cart">
                  <div class="cart-img">
                    <a href="#"><img src="assets/img/cart/2.jpg" alt="" /></a>
                  </div>
                  <div class="cart-title">
                    <h5><a href="#"> Bits Headphone</a></h5>
                    <h6><a href="#">Black</a></h6>
                    <span>$80.00 x 1</span>
                  </div>
                  <div class="cart-delete">
                    <a href="#"><i class="ti-trash"></i></a>
                  </div>
                </li>
                <li class="single-product-cart">
                  <div class="cart-img">
                    <a href="#"><img src="assets/img/cart/3.jpg" alt="" /></a>
                  </div>
                  <div class="cart-title">
                    <h5><a href="#"> Bits Headphone</a></h5>
                    <h6><a href="#">Black</a></h6>
                    <span>$80.00 x 1</span>
                  </div>
                  <div class="cart-delete">
                    <a href="#"><i class="ti-trash"></i></a>
                  </div>
                </li>
                <li class="cart-space">
                  <div class="cart-sub">
                    <h4>Subtotal</h4>
                  </div>
                  <div class="cart-price">
                    <h4>$240.00</h4>
                  </div>
                </li>
                <li class="cart-btn-wrapper">
                  <a class="cart-btn btn-hover" href="#">Voir panier</a>
                  <a class="cart-btn btn-hover" href="#">Commander</a>
                </li>
              </ul>
            </div>
          </div>
          <div
            class="mobile-menu-area clearfix d-md-block col-md-12 col-lg-12 col-12 d-lg-none d-xl-none"
          >
            <div class="mobile-menu">
              <nav id="mobile-menu-active">
                <ul class="menu-overflow">
                  <li><a href="index.php">ACCUEIL</a></li>
                  <li>
                    <a href="#">TELECOMMUNICATION</a>
                    <ul class="single-dropdown">
                      <li>
                        <a href="#">Wifi</a>
                        <ul class="single-dropdown">
                          <li>
                            <a href="liaison_radio.php">Liaison radio</a>
                          </li>
                          <li><a href="bouclier_rf.php">Bouclier RF</a></li>
                          <li>
                            <a href="accessoire_faiwifi.php"
                              >Accessoire FAI WIFI</a
                            >
                          </li>
                        </ul>
                      </li>

                      <li>
                        <a href="#">Fibre optique</a>
                        <ul class="single-dropdown">
                          <li><a href="gpon.php">GPON</a></li>
                          <li><a href="epon.php">EPON</a></li>
                          <li><a href="fusionneuse.php">Fusionneuse</a></li>
                          <li>
                            <a href="boite_d_f.php"
                              >Boiter de distribution de fibre</a
                            >
                          </li>
                          <li><a href="separateur.php">Separateurs</a></li>
                          <li><a href="cable.php">Cable</a></li>
                        </ul>
                      </li>

                      <li><a href="racks_externe.php">Racks exterieurs</a></li>

                      <li><a href="panneaux.php">Panneaux</a></li>

                      <li><a href="refrigelation.php">Refrigélation</a></li>

                      <li><a href="plateaux.php">Plateaux</a></li>

                      <li>
                        <a href="#">Outils</a>
                        <ul class="single-dropdown">
                          <li><a href="etiqueteuse.php">Etiqueteuse</a></li>
                          <li>
                            <a href="malette_outils.php">Malette à outil</a>
                          </li>
                          <li><a href="sertisseuse.php">Sertisseuses</a></li>
                        </ul>
                      </li>
                    </ul>
                  </li>

                  <li>
                    <a href="#">RESEAUX</a>
                    <ul class="single-dropdown">
                      <li>
                        <a href="#">Ethernet</a>
                        <ul class="single-dropdown">
                          <li><a href="routeur.php">Routeurs</a></li>
                          <li>
                            <a href="fibre_optique.php">Fibre optique</a>
                          </li>
                          <li>
                            <a href="convertisseur.php">Convertisseur moyen</a>
                          </li>
                          <li>
                            <a href="adapteur_reseau.php">Adaptateur réseau</a>
                          </li>
                          <li>
                            <a href="accessoire_ethernet.php"
                              >Accessoires Ethernet</a
                            >
                          </li>
                          <li>
                            <a href="outil_ethernet.php">Outils Ethernet</a>
                          </li>
                        </ul>
                      </li>

                      <li>
                        <a href="#">Wifi</a>
                        <ul class="single-dropdown">
                          <li>
                            <a href="couverture_totale.php"
                              >couverture totale</a
                            >
                          </li>
                          <li><a href="point_acces.php">Point d'accès</a></li>
                          <li><a href="controleur_ap.php">Contrleur AP</a></li>
                          <li><a href="repeteur.php">Repéteur</a></li>
                          <li><a href="adaptateur.php">Adaptateur</a></li>
                          <li><a href="routeur_r.php">Routeur</a></li>
                        </ul>
                      </li>
                      <li><a href="gestion.php">Gestion</a></li>
                      <li>
                        <a href="#">4G-LTE</a>
                        <ul class="single-dropdown">
                          <li><a href="routeur_4g.php">Routeur- 4G LTE</a></li>
                          <li>
                            <a href="rayon_ethernet.php">Rayon Ethernet</a>
                          </li>
                          <li><a href="cpe_ethernet.php">CPE Ethernet</a></li>
                          <li><a href="antenne.php">Antenne</a></li>
                        </ul>
                      </li>
                    </ul>
                  </li>

                  <li>
                    <a href="#">SECURITE</a>
                    <ul class="single-dropdown">
                      <li>
                        <a href="paratonnere_parafoud.php"
                          >Paratonnere-parafoudre</a
                        >
                      </li>
                    </ul>
                  </li>

                  <li>
                    <a href="#">ELECTRICITE</a>
                    <ul class="single-dropdown">
                      <li><a href="courant_faible.php">Courant faible</a></li>
                      <li>
                        <a href="paratonnere.php">Paratonnere/parafoudre</a>
                      </li>
                    </ul>
                  </li>

                  <li>
                    <a href="#">TELEPHONE</a>
                    <ul class="single-dropdown">
                      <li><a href="telephone.php">Téléphone</a></li>
                      <li><a href="tablette.php">Tablette</a></li>
                      <li><a href="passerelle_ata.php">Paserelles ATA</a></li>
                    </ul>
                  </li>

                  <li>
                    <a href="#">VIDEOSUEVEILLANCE</a>
                    <ul class="single-dropdown">
                      <li>
                        <a href="camera_surveillance.php"
                          >Caméra de surveillance</a
                        >
                      </li>
                      <li>
                        <a href="camera_thermique.php">Caméra thermique</a>
                      </li>
                      <li><a href="camera_ip.php">Caméra IP</a></li>
                      <li>
                        <a href="#">Visioconférence</a>
                        <ul class="single-dropdown">
                          <li>
                            <a href="visioconference.php">Interphones vidéo</a>
                          </li>
                        </ul>
                      </li>
                    </ul>
                  </li>

                  <li>
                    <a href="#">INFORMATIQUE</a>
                    <ul class="single-dropdown">
                      <li>
                        <a href="armoire_coffret_informatique.php"
                          >Armoire coffret informatique</a
                        >
                      </li>
                      <li><a href="ordinateur.php">Ordinateur</a></li>
                    </ul>
                  </li>

                  <li><a href="about-us.php">SOCIETE</a></li>

                  <li><a href="contact.php">CONTACT</a></li>
                </ul>
              </nav>
            </div>
          </div>

          <div class="slider-area">
            <div class="slider-active owl-carousel">
              <div
                class="single-slider single-slider-hm1 bg-img height-100vh"
                style="background-image: url(assets/img/slider/15.jpg)"
              >
                <div
                  class="slider-content slider-animation slider-content-style-1 slider-animated-1"
                >
                  <h1 class="animated">Fashion</h1>
                  <p class="animated">Create you own style for better looks.</p>
                </div>
                <div class="position-slider-img">
                  <div class="slider-img-1">
                    <img src="assets/img/slider/9.png" alt="" />
                  </div>
                  <div class="slider-img-2">
                    <img class="tilter" src="assets/img/slider/7.png" alt="" />
                  </div>
                  <div class="slider-img-3">
                    <img src="assets/img/slider/8.png" alt="" />
                  </div>
                </div>
              </div>
              <div
                class="single-slider single-slider-hm1 bg-img height-100vh"
                style="background-image: url(assets/img/slider/15.jpg)"
              >
                <div
                  class="slider-content slider-animation slider-content-style-1 slider-animated-2"
                >
                  <h1 class="animated">Fashion</h1>
                  <p class="animated">Create you own style for better looks.</p>
                </div>
                <div class="position-slider-img">
                  <div class="slider-img-1">
                    <img src="assets/img/slider/9.png" alt="" />
                  </div>
                  <div class="slider-img-4 slider-mrg">
                    <img class="tilter" src="assets/img/slider/10.png" alt="" />
                  </div>
                  <div class="slider-img-3">
                    <img src="assets/img/slider/8.png" alt="" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>

    <!-- header end -->
    <!-- banner area start -->
    <div class="banner-area">
      <div class="row g-0">
        <div class="col-md-4">
          <div class="single-banner">
            <a href="#"><img src="assets/img/banner/1.jpg" alt="" /></a>
            <div class="banner-content banner-content-style1">
              <h2>
                BLUE <br />
                <span>Glasses</span>
              </h2>
              <p>Lorem Ipsum is simply dummy text of the printing.</p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="single-banner">
            <a href="#"><img src="assets/img/banner/2.jpg" alt="" /></a>
            <div class="banner-content banner-content-style2">
              <span>- Up to -</span>
              <h2>30% off</h2>
              <p>Black Friday Discount</p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="single-banner">
            <a href="#"><img src="assets/img/banner/3.jpg" alt="" /></a>
            <div class="banner-content banner-content-style3">
              <h2>Trand <br />2018.</h2>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- banner area end -->
    <!-- product area start -->
    <div class="product-area pt-115 pb-120">
      <div class="pl-100 pr-100">
        <div class="container-fluid">
          <div class="section-title text-center mb-60">
            <h2>New Arrivals</h2>
          </div>
          <div class="product-style">
            <div class="arrival-active owl-carousel">
              <div class="product-wrapper">
                <div class="product-img">
                  <a href="#">
                    <img
                      src="assets/img/product/fashion-colorful/1.jpg"
                      alt=""
                    />
                  </a>
                  <span>hot</span>
                  <div class="product-action">
                    <a class="animate-left" title="Wishlist" href="#">
                      <i class="pe-7s-like"></i>
                    </a>
                    <a class="animate-top" title="Add To Cart" href="#">
                      <i class="pe-7s-cart"></i>
                    </a>
                    <a
                      class="animate-right"
                      title="Quick View"
                      data-bs-toggle="modal"
                      data-bs-target="#exampleModal"
                      href="#"
                    >
                      <i class="pe-7s-look"></i>
                    </a>
                  </div>
                </div>
                <div class="product-content">
                  <h4>
                    <a href="product-details.php"> Dagger Smart Trousers </a>
                  </h4>
                  <span>$115.00</span>
                </div>
              </div>
              <div class="product-wrapper">
                <div class="product-img">
                  <a href="#">
                    <img
                      src="assets/img/product/fashion-colorful/2.jpg"
                      alt=""
                    />
                  </a>
                  <div class="product-action">
                    <a class="animate-left" title="Wishlist" href="#">
                      <i class="pe-7s-like"></i>
                    </a>
                    <a class="animate-top" title="Add To Cart" href="#">
                      <i class="pe-7s-cart"></i>
                    </a>
                    <a
                      class="animate-right"
                      title="Quick View"
                      data-bs-toggle="modal"
                      data-bs-target="#exampleModal"
                      href="#"
                    >
                      <i class="pe-7s-look"></i>
                    </a>
                  </div>
                </div>
                <div class="product-content">
                  <h4>
                    <a href="product-details.php">Homme Tapered Smart </a>
                  </h4>
                  <span>$115.00</span>
                </div>
              </div>
              <div class="product-wrapper">
                <div class="product-img">
                  <a href="#">
                    <img
                      src="assets/img/product/fashion-colorful/3.jpg"
                      alt=""
                    />
                  </a>
                  <span>hot</span>
                  <div class="product-action">
                    <a class="animate-left" title="Wishlist" href="#">
                      <i class="pe-7s-like"></i>
                    </a>
                    <a class="animate-top" title="Add To Cart" href="#">
                      <i class="pe-7s-cart"></i>
                    </a>
                    <a
                      class="animate-right"
                      title="Quick View"
                      data-bs-toggle="modal"
                      data-bs-target="#exampleModal"
                      href="#"
                    >
                      <i class="pe-7s-look"></i>
                    </a>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="product-details.php">Navy Bird Print </a></h4>
                  <span>$115.00</span>
                </div>
              </div>
              <div class="product-wrapper">
                <div class="product-img">
                  <a href="#">
                    <img
                      src="assets/img/product/fashion-colorful/4.jpg"
                      alt=""
                    />
                  </a>
                  <div class="product-action">
                    <a class="animate-left" title="Wishlist" href="#">
                      <i class="pe-7s-like"></i>
                    </a>
                    <a class="animate-top" title="Add To Cart" href="#">
                      <i class="pe-7s-cart"></i>
                    </a>
                    <a
                      class="animate-right"
                      title="Quick View"
                      data-bs-toggle="modal"
                      data-bs-target="#exampleModal"
                      href="#"
                    >
                      <i class="pe-7s-look"></i>
                    </a>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="product-details.php">Jacket Stonewash </a></h4>
                  <span>$115.00</span>
                </div>
              </div>
              <div class="product-wrapper">
                <div class="product-img">
                  <a href="#">
                    <img
                      src="assets/img/product/fashion-colorful/5.jpg"
                      alt=""
                    />
                  </a>
                  <span>hot</span>
                  <div class="product-action">
                    <a class="animate-left" title="Wishlist" href="#">
                      <i class="pe-7s-like"></i>
                    </a>
                    <a class="animate-top" title="Add To Cart" href="#">
                      <i class="pe-7s-cart"></i>
                    </a>
                    <a
                      class="animate-right"
                      title="Quick View"
                      data-bs-toggle="modal"
                      data-bs-target="#exampleModal"
                      href="#"
                    >
                      <i class="pe-7s-look"></i>
                    </a>
                  </div>
                </div>
                <div class="product-content">
                  <h4>
                    <a href="product-details.php">Skinny Jeans Terry </a>
                  </h4>
                  <span>$115.00</span>
                </div>
              </div>
              <div class="product-wrapper">
                <div class="product-img">
                  <a href="#">
                    <img
                      src="assets/img/product/fashion-colorful/1.jpg"
                      alt=""
                    />
                  </a>
                  <div class="product-action">
                    <a class="animate-left" title="Wishlist" href="#">
                      <i class="pe-7s-like"></i>
                    </a>
                    <a class="animate-top" title="Add To Cart" href="#">
                      <i class="pe-7s-cart"></i>
                    </a>
                    <a
                      class="animate-right"
                      title="Quick View"
                      data-bs-toggle="modal"
                      data-bs-target="#exampleModal"
                      href="#"
                    >
                      <i class="pe-7s-look"></i>
                    </a>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="product-details.php">Black Faux Suede </a></h4>
                  <span>$115.00</span>
                </div>
              </div>
              <div class="product-wrapper">
                <div class="product-img">
                  <a href="#">
                    <img
                      src="assets/img/product/fashion-colorful/2.jpg"
                      alt=""
                    />
                  </a>
                  <span>hot</span>
                  <div class="product-action">
                    <a class="animate-left" title="Wishlist" href="#">
                      <i class="pe-7s-like"></i>
                    </a>
                    <a class="animate-top" title="Add To Cart" href="#">
                      <i class="pe-7s-cart"></i>
                    </a>
                    <a
                      class="animate-right"
                      title="Quick View"
                      data-bs-toggle="modal"
                      data-bs-target="#exampleModal"
                      href="#"
                    >
                      <i class="pe-7s-look"></i>
                    </a>
                  </div>
                </div>
                <div class="product-content">
                  <h4><a href="product-details.php">Black Faux Suede </a></h4>
                  <span>$115.00</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- product area end -->
    <!-- banner area two start -->
    <div class="banner-area-two">
      <div class="container">
        <div class="row g-0">
          <div class="col-lg-6 col-xl-6">
            <div class="banner-wrapper mrgn-r-4">
              <a href="#"><img src="assets/img/banner/4.jpg" alt="" /></a>
              <div class="banner-wrapper-content">
                <h3>20% <br /><span>off</span></h3>
                <h2><span>Trending</span> <br />Fashion <br />2018...</h2>
              </div>
            </div>
          </div>
          <div class="col-lg-6 col-xl-6">
            <div class="row g-0">
              <div class="col-lg-12">
                <div class="banner-wrapper mrgn-b-4">
                  <a href="#"><img src="assets/img/banner/5.jpg" alt="" /></a>
                  <div class="banner-wrapper-content2">
                    <h3>Winter <br />Collection.</h3>
                    <a href="#">shop now</a>
                  </div>
                </div>
              </div>
              <div class="col-lg-12">
                <div class="row g-0">
                  <div class="col-lg-6">
                    <div class="banner-wrapper mrgn-r-4">
                      <a href="#"
                        ><img src="assets/img/banner/6.jpg" alt=""
                      /></a>
                      <div class="banner-wrapper-content3">
                        <h3><span>new</span> <br />fashion</h3>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="banner-wrapper">
                      <a href="#"
                        ><img src="assets/img/banner/7.jpg" alt=""
                      /></a>
                      <div class="banner-wrapper-content4">
                        <h4>25 December.</h4>
                        <h2>Gift Shop</h2>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- banner area two end -->
    <!-- all products area start -->
    <div class="all-products-area pt-115 pb-50">
      <div class="pl-100 pr-100">
        <div class="container-fluid">
          <div class="section-title text-center mb-60">
            <h2>All Products</h2>
          </div>
          <div class="product-style">
            <div
              class="product-tab-list text-center mb-95 nav product-menu-mrg"
              role="tablist"
            >
              <a
                class="active"
                href="#home1"
                data-bs-toggle="tab"
                role="tab"
                aria-selected="true"
                aria-controls="home1"
              >
                <h4>all</h4>
              </a>
              <a
                href="#home2"
                data-bs-toggle="tab"
                role="tab"
                aria-selected="false"
                aria-controls="home2"
              >
                <h4>woman</h4>
              </a>
              <a
                href="#home3"
                data-bs-toggle="tab"
                role="tab"
                aria-selected="false"
                aria-controls="home3"
              >
                <h4>man</h4>
              </a>
              <a
                href="#home4"
                data-bs-toggle="tab"
                role="tab"
                aria-selected="false"
                aria-controls="home4"
              >
                <h4>ACCESSORIES</h4>
              </a>
              <a
                href="#home5"
                data-bs-toggle="tab"
                role="tab"
                aria-selected="false"
                aria-controls="home5"
              >
                <h4>kids</h4>
              </a>
            </div>
            <div class="tab-content">
              <div class="tab-pane active show fade" id="home1" role="tabpanel">
                <div class="custom-row">
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/1.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Black Faux Suede</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/2.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Denim Stonewash</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/3.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Mini Waffle 5 Pack</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/4.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php"
                            >Dagger Smart Trousers</a
                          >
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/5.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Homme Tapered Smart</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/5.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Navy Bird Print</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/4.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Jacket Stonewash</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/3.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Arifo Stylas Dress </a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/2.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Skinny Jeans Terry</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/1.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Leg Smart Trousers </a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade" id="home2" role="tabpanel">
                <div class="custom-row">
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/5.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Black Faux Suede</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/4.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Leg Smart Trousers</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/3.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Skinny Jeans Terry </a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/2.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Jacket Stonewash</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/1.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Navy Bird Print </a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/1.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Homme Tapered Smart</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/2.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php"
                            >Dagger Smart Trousers
                          </a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/3.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Mini Waffle 5 Pack </a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/4.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Denim Stonewash</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/5.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Navy Bird Print</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade" id="home3" role="tabpanel">
                <div class="custom-row">
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/3.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Black Faux Suede</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/2.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Leg Smart Trousers</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/1.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Skinny Jeans Terry</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/5.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Jacket Stonewash</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/4.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Navy Bird Print</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/5.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Homme Tapered Smart</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/4.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php"
                            >Dagger Smart Trousers</a
                          >
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/2.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Mini Waffle 5 Pack</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/2.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Denim Stonewash</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/3.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Navy Bird Print </a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade" id="home4" role="tabpanel">
                <div class="custom-row">
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/5.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Navy Bird Print</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/3.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Denim Stonewash </a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/4.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Mini Waffle 5 Pack</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/2.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php"
                            >Dagger Smart Trousers</a
                          >
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/1.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Homme Tapered Smart</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/3.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Navy Bird Print</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/5.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Jacket Stonewash</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/1.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Skinny Jeans Terry</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/2.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Leg Smart Trousers</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/1.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Black Faux Suede </a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade" id="home5" role="tabpanel">
                <div class="custom-row">
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/5.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Black Faux Suede</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/1.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Leg Smart Trousers</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/2.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Skinny Jeans Terry</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/3.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Jacket Stonewash</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/4.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Navy Bird Print</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/3.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Homme Tapered Smart</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/4.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php"
                            >Dagger Smart Trousers</a
                          >
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/3.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Mini Waffle 5 Pack </a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/2.jpg"
                            alt=""
                          />
                        </a>
                        <span>hot</span>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Denim Stonewash</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                  <div class="custom-col-5 custom-col-style mb-65">
                    <div class="product-wrapper">
                      <div class="product-img">
                        <a href="#">
                          <img
                            src="assets/img/product/fashion-colorful/1.jpg"
                            alt=""
                          />
                        </a>
                        <div class="product-action">
                          <a class="animate-left" title="Wishlist" href="#">
                            <i class="pe-7s-like"></i>
                          </a>
                          <a class="animate-top" title="Add To Cart" href="#">
                            <i class="pe-7s-cart"></i>
                          </a>
                          <a
                            class="animate-right"
                            title="Quick View"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            href="#"
                          >
                            <i class="pe-7s-look"></i>
                          </a>
                        </div>
                      </div>
                      <div class="product-content">
                        <h4>
                          <a href="product-details.php">Navy Bird Print</a>
                        </h4>
                        <span>$115.00</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- all products area end -->
    <!-- brand logo area start -->
    <div class="brand-logo-area pl-100 pr-100">
      <div class="ptb-135 gray-bg">
        <div class="brand-logo-active owl-carousel">
          <div class="single-brand">
            <img src="assets/img/brand-logo/1.png" alt="" />
          </div>
          <div class="single-brand">
            <img src="assets/img/brand-logo/2.png" alt="" />
          </div>
          <div class="single-brand">
            <img src="assets/img/brand-logo/1.png" alt="" />
          </div>
          <div class="single-brand">
            <img src="assets/img/brand-logo/3.png" alt="" />
          </div>
          <div class="single-brand">
            <img src="assets/img/brand-logo/4.png" alt="" />
          </div>
          <div class="single-brand">
            <img src="assets/img/brand-logo/5.png" alt="" />
          </div>
          <div class="single-brand">
            <img src="assets/img/brand-logo/6.png" alt="" />
          </div>
        </div>
      </div>
    </div>
    <!-- brand logo area end -->
    <!-- banner3 area start -->
    <div class="banner-area3 pt-120 pb-115">
      <div class="pl-100 pr-100">
        <div class="container">
          <div class="row g-0">
            <div class="col-md-12 col-lg-4 col-xl-4">
              <div class="banner-wrapper mrgn-negative">
                <a href="#"><img src="assets/img/banner/8.jpg" alt="" /></a>
                <div class="banner-wrapper2-content">
                  <h3>Speatial</h3>
                  <h2>Style</h2>
                  <span>Start from $299.00</span>
                </div>
              </div>
            </div>
            <div class="col-md-12 col-lg-8 col-xl-8">
              <div class="row g-0 banner-mrg">
                <div class="col-md-6">
                  <div class="banner-wrapper mrgn-b-5 mrgn-r-5">
                    <img src="assets/img/banner/9.jpg" alt="" />
                    <div class="banner-wrapper3-content">
                      <a href="#">Shop Now</a>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="banner-wrapper mrgn-b-5">
                    <img src="assets/img/banner/10.jpg" alt="" />
                    <div class="banner-wrapper3-content banner-text-color">
                      <a href="#">Shop Now</a>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="banner-wrapper mrgn-r-5">
                    <img src="assets/img/banner/11.jpg" alt="" />
                    <div class="banner-wrapper3-content">
                      <a href="#">Shop Now</a>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="banner-wrapper">
                    <img src="assets/img/banner/12.jpg" alt="" />
                    <div class="banner-wrapper3-content">
                      <a href="#">Shop Now</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- banner3 area end -->
    <!-- insta feed start -->
    <div class="insta-feed ptb-120 gray-bg">
      <div class="pl-185 pr-185">
        <div class="section-title-2 text-center mb-50">
          <h2>Insta Feed</h2>
          <h4>Follow us on intagram. <span>@Ezonepro</span></h4>
        </div>
        <div class="instafeed-wrapper">
          <div class="instafeed-active owl-carousel">
            <div class="instafeed-img">
              <img src="assets/img/instra/1.jpg" alt="" />
            </div>
            <div class="instafeed-img">
              <img src="assets/img/instra/2.jpg" alt="" />
            </div>
            <div class="instafeed-img">
              <img src="assets/img/instra/3.jpg" alt="" />
            </div>
            <div class="instafeed-img">
              <img src="assets/img/instra/4.jpg" alt="" />
            </div>
            <div class="instafeed-img">
              <img src="assets/img/instra/5.jpg" alt="" />
            </div>
            <div class="instafeed-img">
              <img src="assets/img/instra/2.jpg" alt="" />
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- insta feed end -->
    <footer class="footer-area">
      <div
        class="footer-top-area bg-img pt-105 pb-65"
        style="background-image: url(assets/img/bg/1.jpg)"
        data-overlay="9"
      >
        <div class="container">
          <div class="row">
            <div class="col-xl-4 col-md-3">
              <div class="footer-widget mb-40">
                <h3 class="footer-widget-title">Custom Service</h3>
                <div class="footer-widget-content">
                  <ul>
                    <li><a href="cart.php">Cart</a></li>
                    <li><a href="register.php">My Account</a></li>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Register</a></li>
                    <li><a href="#">Support</a></li>
                    <li><a href="#">Track</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-xl-4 col-md-3">
              <div class="footer-widget mb-40">
                <h3 class="footer-widget-title">Categories</h3>
                <div class="footer-widget-content">
                  <ul>
                    <li><a href="shop.php">Dress</a></li>
                    <li><a href="shop.php">Shoes</a></li>
                    <li><a href="shop.php">Shirt</a></li>
                    <li><a href="shop.php">Baby Product</a></li>
                    <li><a href="shop.php">Mans Product</a></li>
                    <li><a href="shop.php">Leather</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-xl-4 col-md-6">
              <div class="footer-widget mb-40">
                <h3 class="footer-widget-title">Contact</h3>
                <div class="footer-newsletter">
                  <p>
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum is dummy.
                  </p>
                  <div id="mc_embed_signup" class="subscribe-form pr-40">
                    <form
                      action="https://devitems.us11.list-manage.com/subscribe/post?u=6bbb9b6f5827bd842d9640c82&amp;id=05d85f18ef"
                      method="post"
                      id="mc-embedded-subscribe-form"
                      name="mc-embedded-subscribe-form"
                      class="validate"
                      target="_blank"
                      novalidate
                    >
                      <div id="mc_embed_signup_scroll" class="mc-form">
                        <input
                          type="email"
                          value=""
                          name="EMAIL"
                          class="email"
                          placeholder="Enter Your E-mail"
                          required
                        />
                        <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                        <div class="mc-news" aria-hidden="true">
                          <input
                            type="text"
                            name="b_6bbb9b6f5827bd842d9640c82_05d85f18ef"
                            tabindex="-1"
                            value=""
                          />
                        </div>
                        <div class="clear">
                          <input
                            type="submit"
                            value="Subscribe"
                            name="subscribe"
                            id="mc-embedded-subscribe"
                            class="button"
                          />
                        </div>
                      </div>
                    </form>
                  </div>
                  <div class="footer-contact">
                    <p>
                      <span><i class="ti-location-pin"></i></span> 77 Seventh
                      avenue USA 12555.
                    </p>
                    <p>
                      <span><i class="ti-headphone-alt"></i></span> +88 (015)
                      609735 or +88 (012) 112266
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="footer-bottom black-bg ptb-20">
        <div class="container">
          <div class="row">
            <div class="col-12 text-center">
              <div class="copyright">
                <p>
                  Copyright ©
                  <a href="hastech.company/">HasTech</a> 2021 . All Right
                  Reserved.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- modal -->
    <div
      class="modal fade"
      id="exampleModal"
      tabindex="-1"
      role="dialog"
      aria-hidden="true"
    >
      <button
        type="button"
        class="close"
        data-bs-dismiss="modal"
        aria-label="Close"
      >
        <span class="pe-7s-close" aria-hidden="true"></span>
      </button>
      <div class="modal-dialog modal-quickview-width" role="document">
        <div class="modal-content">
          <div class="modal-body">
            <div class="qwick-view-left">
              <div class="quick-view-learg-img">
                <div class="quick-view-tab-content tab-content">
                  <div
                    class="tab-pane active show fade"
                    id="modal1"
                    role="tabpanel"
                  >
                    <img src="assets/img/quick-view/l1.jpg" alt="" />
                  </div>
                  <div class="tab-pane fade" id="modal2" role="tabpanel">
                    <img src="assets/img/quick-view/l2.jpg" alt="" />
                  </div>
                  <div class="tab-pane fade" id="modal3" role="tabpanel">
                    <img src="assets/img/quick-view/l3.jpg" alt="" />
                  </div>
                </div>
              </div>
              <div class="quick-view-list nav" role="tablist">
                <a
                  class="active"
                  href="#modal1"
                  data-bs-toggle="tab"
                  role="tab"
                  aria-selected="true"
                  aria-controls="home1"
                >
                  <img src="assets/img/quick-view/s1.jpg" alt="" />
                </a>
                <a
                  href="#modal2"
                  data-bs-toggle="tab"
                  role="tab"
                  aria-selected="false"
                  aria-controls="home2"
                >
                  <img src="assets/img/quick-view/s2.jpg" alt="" />
                </a>
                <a
                  href="#modal3"
                  data-bs-toggle="tab"
                  role="tab"
                  aria-selected="false"
                  aria-controls="home3"
                >
                  <img src="assets/img/quick-view/s3.jpg" alt="" />
                </a>
              </div>
            </div>
            <div class="qwick-view-right">
              <div class="qwick-view-content">
                <h3>Handcrafted Supper Mug</h3>
                <div class="price">
                  <span class="new">$90.00</span>
                  <span class="old">$120.00 </span>
                </div>
                <div class="rating-number">
                  <div class="quick-view-rating">
                    <i class="pe-7s-star"></i>
                    <i class="pe-7s-star"></i>
                    <i class="pe-7s-star"></i>
                    <i class="pe-7s-star"></i>
                    <i class="pe-7s-star"></i>
                  </div>
                  <div class="quick-view-number">
                    <span>2 Ratting (S)</span>
                  </div>
                </div>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adip elit, sed do
                  tempor incididun ut labore et dolore magna aliqua. Ut enim ad
                  mi , quis nostrud veniam exercitation .
                </p>
                <div class="quick-view-select">
                  <div class="select-option-part">
                    <label>Size*</label>
                    <select class="select">
                      <option value="">- Please Select -</option>
                      <option value="">900</option>
                      <option value="">700</option>
                    </select>
                  </div>
                  <div class="select-option-part">
                    <label>Color*</label>
                    <select class="select">
                      <option value="">- Please Select -</option>
                      <option value="">orange</option>
                      <option value="">pink</option>
                      <option value="">yellow</option>
                    </select>
                  </div>
                </div>
                <div class="quickview-plus-minus">
                  <div class="cart-plus-minus">
                    <input
                      type="text"
                      value="02"
                      name="qtybutton"
                      class="cart-plus-minus-box"
                    />
                  </div>
                  <div class="quickview-btn-cart">
                    <a class="btn-hover-black" href="#">add to cart</a>
                  </div>
                  <div class="quickview-btn-wishlist">
                    <a class="btn-hover" href="#"><i class="pe-7s-like"></i></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- all js here -->
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="assets/js/popper.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/ajax-mail.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>
  </body>
</html>
