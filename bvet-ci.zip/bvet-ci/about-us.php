<!DOCTYPE html>
<html class="no-js" lang="zxx">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <title>bvet-ci</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!-- Favicon -->
    <link
      rel="shortcut icon"
      type="image/x-icon"
      href="assets/img/favicon.png"
    />

    <!-- all css here -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/magnific-popup.css" />
    <link rel="stylesheet" href="assets/css/animate.css" />
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="assets/css/themify-icons.css" />
    <link rel="stylesheet" href="assets/css/pe-icon-7-stroke.css" />
    <link rel="stylesheet" href="assets/css/icofont.css" />
    <link rel="stylesheet" href="assets/css/meanmenu.min.css" />
    <link rel="stylesheet" href="assets/css/bundle.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/responsive.css" />
    <script src="assets/js/vendor/modernizr-3.11.7.min.js"></script>
  </head>
  <body>
    <!--[if lt IE 8]>
      <p class="browserupgrade">
        You are using an <strong>outdated</strong> browser. Please
        <a href="https://browsehappy.com/">upgrade your browser</a> to improve
        your experience.
      </p>
    <![endif]-->
    <!-- header start -->
    <header>
      <div class="header-top-furniture wrapper-padding-2 res-header-sm">
        <div class="container-fluid">
          <div class="header-bottom-wrapper">
            <div class="logo-2 furniture-logo ptb-30">
              <a href="index.php">
                <img src="assets/img/logo/2.png" alt="" />
              </a>
            </div>
            <div class="menu-style-2 furniture-menu menu-hover">
              <nav>
                <ul>
                  <li><a href="index.php">ACCUEIL</a></li>
                  <li>
                    <a href="#">TELECOMMUNICATION</a>
                    <ul class="single-dropdown">
                      <li>
                        <a href="#">Wifi</a>
                        <ul class="single-dropdown">
                          <li>
                            <a href="liaison_radio.php">Liaison radio</a>
                          </li>
                          <li><a href="bouclier_rf.php">Bouclier RF</a></li>
                          <li>
                            <a href="accessoire_faiwifi.php"
                              >Accessoire FAI WIFI</a
                            >
                          </li>
                        </ul>
                      </li>

                      <li>
                        <a href="#">Fibre optique</a>
                        <ul class="single-dropdown">
                          <li><a href="gpon.php">GPON</a></li>
                          <li><a href="epon.php">EPON</a></li>
                          <li><a href="fusionneuse.php">Fusionneuse</a></li>
                          <li>
                            <a href="boite_d_f.php"
                              >Boiter de distribution de fibre</a
                            >
                          </li>
                          <li><a href="separateur.php">Separateurs</a></li>
                          <li><a href="cable.php">Cable</a></li>
                        </ul>
                      </li>

                      <li><a href="racks_externe.php">Racks exterieurs</a></li>

                      <li><a href="panneaux.php">Panneaux</a></li>

                      <li><a href="refrigelation.php">Refrigélation</a></li>

                      <li><a href="plateaux.php">Plateaux</a></li>

                      <li>
                        <a href="#">Outils</a>
                        <ul class="single-dropdown">
                          <li><a href="etiqueteuse.php">Etiqueteuse</a></li>
                          <li>
                            <a href="malette_outils.php">Malette à outil</a>
                          </li>
                          <li><a href="sertisseuse.php">Sertisseuses</a></li>
                        </ul>
                      </li>
                    </ul>
                  </li>

                  <li>
                    <a href="#">RESEAUX</a>
                    <ul class="single-dropdown">
                      <li>
                        <a href="#">Ethernet</a>
                        <ul class="single-dropdown">
                          <li><a href="routeur.php">Routeurs</a></li>
                          <li>
                            <a href="fibre_optique.php">Fibre optique</a>
                          </li>
                          <li>
                            <a href="convertisseur.php">Convertisseur moyen</a>
                          </li>
                          <li>
                            <a href="adapteur_reseau.php">Adaptateur réseau</a>
                          </li>
                          <li>
                            <a href="accessoire_ethernet.php"
                              >Accessoires Ethernet</a
                            >
                          </li>
                          <li>
                            <a href="outil_ethernet.php">Outils Ethernet</a>
                          </li>
                        </ul>
                      </li>

                      <li>
                        <a href="#">Wifi</a>
                        <ul class="single-dropdown">
                          <li>
                            <a href="couverture_totale.php"
                              >couverture totale</a
                            >
                          </li>
                          <li><a href="point_acces.php">Point d'accès</a></li>
                          <li><a href="controleur_ap.php">Contrleur AP</a></li>
                          <li><a href="repeteur.php">Repéteur</a></li>
                          <li><a href="adaptateur.php">Adaptateur</a></li>
                          <li><a href="routeur_r.php">Routeur</a></li>
                        </ul>
                      </li>

                      <li><a href="menu-list.php">Gestion</a></li>

                      <li>
                        <a href="#">4G-LTE</a>
                        <ul class="single-dropdown">
                          <li><a href="routeur_4g.php">Routeur- 4G LTE</a></li>
                          <li>
                            <a href="rayon_ethernet.php">Rayon Ethernet</a>
                          </li>
                          <li><a href="cpe_ethernet.php">CPE Ethernet</a></li>
                          <li><a href="antenne.php">Antenne</a></li>
                        </ul>
                      </li>
                    </ul>
                  </li>

                  <li>
                    <a href="#">SECURITE</a>
                    <ul class="single-dropdown">
                      <li>
                        <a href="paratonnere_parafoud.php"
                          >Paratonnere-parafoudre</a
                        >
                      </li>
                    </ul>
                  </li>

                  <li>
                    <a href="#">ELECTRICITE</a>
                    <ul class="single-dropdown">
                      <li><a href="courant_faible.php">Courant faible</a></li>
                      <li>
                        <a href="paratonnere.php">Paratonnere/parafoudre</a>
                      </li>
                    </ul>
                  </li>

                  <li>
                      <a href="#">TELEPHONE</a>
                      <ul class="single-dropdown">
                       <li>
                          <a href="#">Téléphone</a>
                          <ul class="single-dropdown">
                            <li>
                              <a href="téléphone_ip.php">Téléphone IP</a>
                            </li>
                            <li><a href="téléphone_vidéo.php">Téléphone vidéo IP</a></li>
                            <li>
                              <a href="téléphon_ip_dect.php"
                                >Téléphone IP dect </a
                              >
                            </li>
                          </ul>
                        </li>

                       <li>
                          <a href="#">Tableaux</a>
                          <ul class="single-dropdown">
                            <li>
                              <a href="petit_tablau.php">Pétit tableau</a>
                            </li>
                            <li><a href="module_pbx.php">Modules PBX</a></li>
                          </ul>
                        </li>
                          <a href="passerelle_ata.php">Paserelles ATA</a>
                    </li>

                  <li>
                    <a href="#">VIDEOSUEVEILLANCE</a>
                    <ul class="single-dropdown">
                      <li>
                        <a href="camera_surveillance.php"
                          >Caméra de surveillance</a
                        >
                      </li>
                      <li>
                        <a href="camera_thermique.php">Caméra thermique</a>
                      </li>
                      <li><a href="camera_ip.php">Caméra IP</a></li>
                      <li>
                        <a href="#">Visioconférence</a>
                        <ul class="single-dropdown">
                          <li>
                            <a href="visioconference.php">Interphones vidéo</a>
                          </li>
                        </ul>
                      </li>
                    </ul>
                  </li>

                  <li>
                    <a href="#">INFORMATIQUE</a>
                    <ul class="single-dropdown">
                      <li>
                        <a href="armoire_coffret_informatique.php"
                          >Armoire coffret informatique</a
                        >
                      </li>
                      <li><a href="ordinateur.php">Ordinateur</a></li>
                    </ul>
                  </li>

                  <li><a href="about-us.php">SOCIETE</a></li>

                  <li><a href="contact.php">CONTACT</a></li>
                </ul>
              </nav>
            </div>
            <div class="header-cart">
              <a class="icon-cart-furniture" href="#">
                <i class="ti-shopping-cart"></i>
                <span class="shop-count-furniture green">02</span>
              </a>
              <ul class="cart-dropdown">
                <li class="single-product-cart">
                  <div class="cart-img">
                    <a href="#"><img src="assets/img/cart/1.jpg" alt="" /></a>
                  </div>
                  <div class="cart-title">
                    <h5><a href="#"> Bits Headphone</a></h5>
                    <h6><a href="#">Black</a></h6>
                    <span>$80.00 x 1</span>
                  </div>
                  <div class="cart-delete">
                    <a href="#"><i class="ti-trash"></i></a>
                  </div>
                </li>
                <li class="single-product-cart">
                  <div class="cart-img">
                    <a href="#"><img src="assets/img/cart/2.jpg" alt="" /></a>
                  </div>
                  <div class="cart-title">
                    <h5><a href="#"> Bits Headphone</a></h5>
                    <h6><a href="#">Black</a></h6>
                    <span>$80.00 x 1</span>
                  </div>
                  <div class="cart-delete">
                    <a href="#"><i class="ti-trash"></i></a>
                  </div>
                </li>
                <li class="single-product-cart">
                  <div class="cart-img">
                    <a href="#"><img src="assets/img/cart/3.jpg" alt="" /></a>
                  </div>
                  <div class="cart-title">
                    <h5><a href="#"> Bits Headphone</a></h5>
                    <h6><a href="#">Black</a></h6>
                    <span>$80.00 x 1</span>
                  </div>
                  <div class="cart-delete">
                    <a href="#"><i class="ti-trash"></i></a>
                  </div>
                </li>
                <li class="cart-space">
                  <div class="cart-sub">
                    <h4>Total</h4>
                  </div>
                  <div class="cart-price">
                    <h4>$240.00</h4>
                  </div>
                </li>
                <li class="cart-btn-wrapper">
                  <a class="cart-btn btn-hover" href="#">Voir panier</a>
                  <a class="cart-btn btn-hover" href="#">commander</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="row">
            <div
              class="mobile-menu-area d-md-block col-md-12 col-lg-12 col-12 d-lg-none d-xl-none"
            >
              <div class="mobile-menu">
                <nav id="mobile-menu-active">
                  <ul class="menu-overflow">
                    <li><a href="index.php">ACCUEIL</a></li>
                    <li>
                      <a href="#">TELECOMMUNICATION</a>
                      <ul class="single-dropdown">
                        <li>
                          <a href="#">Wifi</a>
                          <ul class="single-dropdown">
                            <li>
                              <a href="liaison_radio.php">Liaison radio</a>
                            </li>
                            <li><a href="bouclier_rf.php">Bouclier RF</a></li>
                            <li>
                              <a href="accessoire_faiwifi.php"
                                >Accessoire FAI WIFI</a
                              >
                            </li>
                          </ul>
                        </li>

                        <li>
                          <a href="#">Fibre optique</a>
                          <ul class="single-dropdown">
                            <li><a href="gpon.php">GPON</a></li>
                            <li><a href="epon.php">EPON</a></li>
                            <li><a href="fusionneuse.php">Fusionneuse</a></li>
                            <li>
                              <a href="boite_d_f.php"
                                >Boiter de distribution de fibre</a
                              >
                            </li>
                            <li><a href="separateur.php">Separateurs</a></li>
                            <li><a href="cable.php">Cable</a></li>
                          </ul>
                        </li>

                        <li>
                          <a href="racks_externe.php">Racks exterieurs</a>
                        </li>

                        <li><a href="panneaux.php">Panneaux</a></li>

                        <li><a href="refrigelation.php">Refrigélation</a></li>

                        <li><a href="plateaux.php">Plateaux</a></li>

                        <li>
                          <a href="#">Outils</a>
                          <ul class="single-dropdown">
                            <li><a href="etiqueteuse.php">Etiqueteuse</a></li>
                            <li>
                              <a href="malette_outils.php">Malette à outil</a>
                            </li>
                            <li><a href="sertisseuse.php">Sertisseuses</a></li>
                          </ul>
                        </li>
                      </ul>
                    </li>

                    <li>
                      <a href="#">RESEAUX</a>
                      <ul class="single-dropdown">
                        <li>
                          <a href="#">Ethernet</a>
                          <ul class="single-dropdown">
                            <li><a href="routeur.php">Routeurs</a></li>
                            <li>
                              <a href="fibre_optique.php">Fibre optique</a>
                            </li>
                            <li>
                              <a href="convertisseur.php"
                                >Convertisseur moyen</a
                              >
                            </li>
                            <li>
                              <a href="adapteur_reseau.php"
                                >Adaptateur réseau</a
                              >
                            </li>
                            <li>
                              <a href="accessoire_ethernet.php"
                                >Accessoires Ethernet</a
                              >
                            </li>
                            <li>
                              <a href="outil_ethernet.php">Outils Ethernet</a>
                            </li>
                          </ul>
                        </li>

                        <li>
                          <a href="#">Wifi</a>
                          <ul class="single-dropdown">
                            <li>
                              <a href="couverture_totale.php"
                                >couverture totale</a
                              >
                            </li>
                            <li>
                              <a href="point_acces.php">Point d'accès</a>
                            </li>
                            <li>
                              <a href="controleur_ap.php">Contrleur AP</a>
                            </li>
                            <li><a href="repeteur.php">Repéteur</a></li>
                            <li><a href="adaptateur.php">Adaptateur</a></li>
                            <li><a href="routeur_r.php">Routeur</a></li>
                          </ul>
                        </li>

                        <li><a href="menu-list.php">Gestion</a></li>

                        <li>
                          <a href="#">4G-LTE</a>
                          <ul class="single-dropdown">
                            <li>
                              <a href="routeur_4g.php">Routeur- 4G LTE</a>
                            </li>
                            <li>
                              <a href="rayon_ethernet.php">Rayon Ethernet</a>
                            </li>
                            <li>
                              <a href="cpe_ethernet.php">CPE Ethernet</a>
                            </li>
                            <li><a href="antenne.php">Antenne</a></li>
                          </ul>
                        </li>
                      </ul>
                    </li>

                    <li>
                      <a href="#">SECURITE</a>
                      <ul class="single-dropdown">
                        <li>
                          <a href="paratonnere_parafoud.php"
                            >Paratonnere-parafoudre</a
                          >
                        </li>
                      </ul>
                    </li>

                    <li>
                      <a href="#">ELECTRICITE</a>
                      <ul class="single-dropdown">
                        <li>
                          <a href="courant_faible.php">Courant faible</a>
                        </li>
                        <li>
                          <a href="paratonnere.php">Paratonnere/parafoudre</a>
                        </li>
                      </ul>
                    </li>

                    <li>
                      <a href="#">TELEPHONE</a>
                      <ul class="single-dropdown">
                       <li>
                          <a href="#">Téléphone</a>
                          <ul class="single-dropdown">
                            <li>
                              <a href="téléphone_ip.php">Téléphone IP</a>
                            </li>
                            <li><a href="téléphone_vidéo.php">Téléphone vidéo IP</a></li>
                            <li>
                              <a href="téléphon_ip_dect.php"
                                >Téléphone IP dect </a
                              >
                            </li>
                          </ul>
                        </li>

                       <li>
                          <a href="#">Tableaux</a>
                          <ul class="single-dropdown">
                            <li>
                              <a href="petit_tablau.php">Pétit tableau</a>
                            </li>
                            <li><a href="module_pbx.php">Modules PBX</a></li>
                          </ul>
                        </li>
                          <a href="passerelle_ata.php">Paserelles ATA</a>
                    </li>
                      </ul>
                    </li>

                    <li>
                      <a href="#">VIDEOSUEVEILLANCE</a>
                      <ul class="single-dropdown">
                        <li>
                          <a href="camera_surveillance.php"
                            >Caméra de surveillance</a
                          >
                        </li>
                        <li>
                          <a href="camera_thermique.php">Caméra thermique</a>
                        </li>
                        <li><a href="camera_ip.php">Caméra IP</a></li>
                        <li>
                          <a href="#">Visioconférence</a>
                          <ul class="single-dropdown">
                            <li>
                              <a href="visioconference.php"
                                >Interphones vidéo</a
                              >
                            </li>
                          </ul>
                        </li>
                      </ul>
                    </li>

                    <li>
                      <a href="#">INFORMATIQUE</a>
                      <ul class="single-dropdown">
                        <li>
                          <a href="armoire_coffret_informatique.php"
                            >Armoire coffret informatique</a
                          >
                        </li>
                        <li><a href="ordinateur.php">Ordinateur</a></li>
                      </ul>
                    </li>

                    <li><a href="about-us.php">SOCIETE</a></li>

                    <li><a href="contact.php">CONTACT</a></li>
                  </ul>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="header-bottom-furniture wrapper-padding-2 border-top-3">
        <div class="container-fluid">
          <div class="furniture-bottom-wrapper">
            <div class="furniture-login">
              <ul>
                <li>Avoir accès: <a href="login.php">CONNEXION </a></li>
                <li><a href="register.php">S'INSCRIRE </a></li>
              </ul>
            </div>
            <div class="furniture-search">
              <form action="#">
                <input placeholder="Recherche " type="text" />
                <button>
                  <i class="ti-search"></i>
                </button>
              </form>
            </div>
            <div class="furniture-wishlist">
              <ul>
                <li>
                  <a
                    data-bs-toggle="modal"
                    data-target="#exampleCompare"
                    href="#"
                    ><i class="ti-reload"></i> Comparer</a
                  >
                </li>
                <li>
                  <a href="wishlist.php"
                    ><i class="ti-heart"></i> Liste de souhaits</a
                  >
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </header>

    <!-- header end -->
    <div
      class="breadcrumb-area pt-205 pb-210"
      style="background-image: url(assets/img/bg/breadcrumb.jpg)"
    >
      <div class="container">
        <div class="breadcrumb-content text-center">
          <h2>A propos</h2>
          <ul>
            <li><a href="#">Accueil</a></li>
            <li>Société</li>
          </ul>
        </div>
      </div>
    </div>
    <div class="about-story pt-95 pb-100">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <div class="story-img">
              <img src="assets/img/banner/11.png" alt="" />
              <div class="about-logo">
                <h3>bvet</h3>
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="story-details pl-50">
              <div class="story-details-top">
                <h2>Bienvenue à <span>bvet</span></h2>
                <p>
                  ezone provide how all this mistaken idea of denouncing
                  pleasure and sing pain was born an will give you a complete
                  account of the system, and expound the actual teachings of the
                  eat explorer.
                </p>
              </div>
              <div class="story-details-bottom">
                <h4>WE START AT 2015</h4>
                <p>
                  ezone provide how all this mistaken idea of denouncing
                  pleasure and sing pain was born an will give you a complete
                  account of the system, and expound the actual teachings of the
                  eat explorer.
                </p>
              </div>
              <div class="story-details-bottom">
                <h4>WIN BEST ONLINE SHOP AT 2017</h4>
                <p>
                  ezone provide how all this mistaken idea of denouncing
                  pleasure and sing pain was born an will give you a complete
                  account of the system, and expound the actual teachings of the
                  eat explorer.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="about-banner-area pb-65">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <div class="banner-wrapper-4 mb-30">
              <a href="#"><img src="assets/img/banner/37.jpg" alt="" /></a>
              <div class="banner-content4-style1">
                <h4>Best <br />Electronics <br />Products.</h4>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="banner-wrapper-4 mb-30">
              <a href="#"><img src="assets/img/banner/21.jpg" alt="" /></a>
              <div class="banner-content4-style2">
                <h5 class="p-left">get</h5>
                <h2>25%</h2>
                <h5 class="p-right">off</h5>
                <h3>Bitso X1202</h3>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="banner-wrapper-4 mb-30">
              <a href="#"><img src="assets/img/banner/22.jpg" alt="" /></a>
              <div class="banner-content4-style3">
                <h1>Up to <br />10% Off</h1>
                <h3>Lonovo Vio D22</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="goal-area pb-65">
      <div class="container">
        <div class="row">
          <div class="col-lg-4">
            <div class="goal-wrapper mb-30">
              <h3>OUR VISSION</h3>
              <p>
                ezone provide how all this mistaken idea of denouncing pleasure
                and sing pain was born an will give you a ete account of the
                system, and expound the actual teangs of the eat explorer of the
                truth.
              </p>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="goal-wrapper mb-30">
              <h3>OUR MISSION</h3>
              <p>
                ezone provide how all this mistaken idea of denouncing pleasure
                and sing pain was born an will give you a ete account of the
                system, and expound the actual teangs of the eat explorer of the
                truth.
              </p>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="goal-wrapper mb-30">
              <h3>OUR GOAL</h3>
              <p>
                ezone provide how all this mistaken idea of denouncing pleasure
                and sing pain was born an will give you a ete account of the
                system, and expound the actual teangs of the eat explorer of the
                truth.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="choose-area pb-100">
      <div class="container">
        <div class="about-section">
          <h3>
            YOU CAN CHOOSE US BECAUSE <br />WE ALWAYS PROVIDE IMPORTANCE...
          </h3>
          <p>
            ezone provide how all this mistaken idea of denouncing pleasure and
            sing pain was born will give you a complete account of the system,
            and expound the actual
          </p>
        </div>
        <div class="row">
          <div class="col-lg-7 col-md-12">
            <div class="all-causes">
              <div class="row">
                <div class="col-md-6 causes-res">
                  <div class="choose-wrapper">
                    <h4>FAST DELIVERY</h4>
                    <p>
                      ezone provide how all this mistaken dea of denouncing
                      pleasure and sing
                    </p>
                  </div>
                  <div class="choose-wrapper">
                    <h4>SECURE PAYMENT</h4>
                    <p>
                      ezone provide how all this mistaken dea of denouncing
                      pleasure and sing
                    </p>
                  </div>
                  <div class="choose-wrapper">
                    <h4>EASY ORDER TRACKING</h4>
                    <p>
                      ezone provide how all this mistaken dea of denouncing
                      pleasure and sing
                    </p>
                  </div>
                  <div class="choose-wrapper">
                    <h4>24/7 SUPPORT</h4>
                    <p>
                      ezone provide how all this mistaken dea of denouncing
                      pleasure and sing
                    </p>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="choose-wrapper">
                    <h4>QUALITY PRODUCT</h4>
                    <p>
                      ezone provide how all this mistaken dea of denouncing
                      pleasure and sing
                    </p>
                  </div>
                  <div class="choose-wrapper">
                    <h4>MONEY BACK GUARNTEE</h4>
                    <p>
                      ezone provide how all this mistaken dea of denouncing
                      pleasure and sing
                    </p>
                  </div>
                  <div class="choose-wrapper">
                    <h4>FREE RETURN</h4>
                    <p>
                      ezone provide how all this mistaken dea of denouncing
                      pleasure and sing
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-5 col-md-12">
            <div class="choose-banner-wrapper f-right">
              <img src="assets/img/banner/38.jpg" alt="" />
              <div class="choose-banner-text">
                <h4>DEALS <br />OF THE DAY</h4>
                <h3>UP TO <br /><span>50%</span> <br />OFF</h3>
                <a href="#">SHOP NOW </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="team-area">
      <img src="assets/img/banner/39.jpg" alt="" />
    </div>
    <!-- testimonials area start -->
    <div
      class="testimonials-area pt-100 pb-95 bg-img"
      style="background-image: url(assets/img/bg/7.jpg)"
    >
      <div class="container">
        <div class="testimonials-active owl-carousel">
          <div class="single-testimonial-2 text-center">
            <img src="assets/img/team/1.png" alt="" />
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim ad minim veniam, quis nostrud exercitation.
            </p>
            <img src="assets/img/team/2.png" alt="" />
            <h4>tayeb rayed</h4>
            <span>uiux Designer</span>
          </div>
        </div>
      </div>
    </div>
    <!-- testimonials area end -->
    <footer class="footer-area">
      <div
        class="footer-top-area bg-img pt-105 pb-65"
        style="background-image: url(assets/img/bg/1.jpg)"
        data-overlay="9"
      >
        <div class="container">
          <div class="row">
            <div class="col-xl-4 col-md-3">
              <div class="footer-widget mb-40">
                <h3 class="footer-widget-title">Custom Service</h3>
                <div class="footer-widget-content">
                  <ul>
                    <li><a href="cart.php">Cart</a></li>
                    <li><a href="register.php">My Account</a></li>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Register</a></li>
                    <li><a href="#">Support</a></li>
                    <li><a href="#">Track</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-xl-4 col-md-3">
              <div class="footer-widget mb-40">
                <h3 class="footer-widget-title">Categories</h3>
                <div class="footer-widget-content">
                  <ul>
                    <li><a href="shop.php">Dress</a></li>
                    <li><a href="shop.php">Shoes</a></li>
                    <li><a href="shop.php">Shirt</a></li>
                    <li><a href="shop.php">Baby Product</a></li>
                    <li><a href="shop.php">Mans Product</a></li>
                    <li><a href="shop.php">Leather</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-xl-4 col-md-6">
              <div class="footer-widget mb-40">
                <h3 class="footer-widget-title">Contact</h3>
                <div class="footer-newsletter">
                  <p>
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum is dummy.
                  </p>
                  <div id="mc_embed_signup" class="subscribe-form pr-40">
                    <form
                      action="https://devitems.us11.list-manage.com/subscribe/post?u=6bbb9b6f5827bd842d9640c82&amp;id=05d85f18ef"
                      method="post"
                      id="mc-embedded-subscribe-form"
                      name="mc-embedded-subscribe-form"
                      class="validate"
                      target="_blank"
                      novalidate
                    >
                      <div id="mc_embed_signup_scroll" class="mc-form">
                        <input
                          type="email"
                          value=""
                          name="EMAIL"
                          class="email"
                          placeholder="Enter Your E-mail"
                          required
                        />
                        <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                        <div class="mc-news" aria-hidden="true">
                          <input
                            type="text"
                            name="b_6bbb9b6f5827bd842d9640c82_05d85f18ef"
                            tabindex="-1"
                            value=""
                          />
                        </div>
                        <div class="clear">
                          <input
                            type="submit"
                            value="Subscribe"
                            name="subscribe"
                            id="mc-embedded-subscribe"
                            class="button"
                          />
                        </div>
                      </div>
                    </form>
                  </div>
                  <div class="footer-contact">
                    <p>
                      <span><i class="ti-location-pin"></i></span> 77 Seventh
                      avenue USA 12555.
                    </p>
                    <p>
                      <span><i class="ti-headphone-alt"></i></span> +88 (015)
                      609735 or +88 (012) 112266
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="footer-bottom black-bg ptb-20">
        <div class="container">
          <div class="row">
            <div class="col-12 text-center">
              <div class="copyright">
                <p>
                  Copyright ©
                  <a href="hastech.company/">HasTech</a> 2021 . All Right
                  Reserved.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- modal -->
    <div
      class="modal fade"
      id="exampleCompare"
      tabindex="-1"
      role="dialog"
      aria-hidden="true"
    >
      <button
        type="button"
        class="close"
        data-bs-dismiss="modal"
        aria-label="Close"
      >
        <span class="pe-7s-close" aria-hidden="true"></span>
      </button>
      <div class="modal-dialog modal-compare-width" role="document">
        <div class="modal-content">
          <div class="modal-body">
            <form action="#">
              <div class="table-content compare-style table-responsive">
                <table>
                  <thead>
                    <tr>
                      <th></th>
                      <th>
                        <a href="#">Remove <span>x</span></a>
                        <img src="assets/img/cart/4.jpg" alt="" />
                        <p>Blush Sequin Top</p>
                        <span>$75.99</span>
                        <a class="compare-btn" href="#">Add to cart</a>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td class="compare-title"><h4>Description</h4></td>
                      <td class="compare-dec compare-common">
                        <p>
                          Lorem Ipsum is simply dummy text of the printing and
                          typesetting industry. Lorem Ipsum has beenin the stand
                          ard dummy text ever since the 1500s, when an unknown
                          printer took a galley
                        </p>
                      </td>
                    </tr>
                    <tr>
                      <td class="compare-title"><h4>Sku</h4></td>
                      <td class="product-none compare-common">
                        <p>-</p>
                      </td>
                    </tr>
                    <tr>
                      <td class="compare-title"><h4>Availability</h4></td>
                      <td class="compare-stock compare-common">
                        <p>In stock</p>
                      </td>
                    </tr>
                    <tr>
                      <td class="compare-title"><h4>Weight</h4></td>
                      <td class="compare-none compare-common">
                        <p>-</p>
                      </td>
                    </tr>
                    <tr>
                      <td class="compare-title"><h4>Dimensions</h4></td>
                      <td class="compare-stock compare-common">
                        <p>N/A</p>
                      </td>
                    </tr>
                    <tr>
                      <td class="compare-title"><h4>brand</h4></td>
                      <td class="compare-brand compare-common">
                        <p>HasTech</p>
                      </td>
                    </tr>
                    <tr>
                      <td class="compare-title"><h4>color</h4></td>
                      <td class="compare-color compare-common">
                        <p>Grey, Light Yellow, Green, Blue, Purple, Black</p>
                      </td>
                    </tr>
                    <tr>
                      <td class="compare-title"><h4>size</h4></td>
                      <td class="compare-size compare-common">
                        <p>XS, S, M, L, XL, XXL</p>
                      </td>
                    </tr>
                    <tr>
                      <td class="compare-title"></td>
                      <td class="compare-price compare-common">
                        <p>$75.99</p>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- all js here -->
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="assets/js/popper.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/ajax-mail.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>
  </body>
</html>
