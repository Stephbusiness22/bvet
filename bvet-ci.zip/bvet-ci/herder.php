<header>
  <div class="header-area">
    <div class="header-left-sidebar">
      <div class="logo">
        <a href="index.html"><img src="assets/img/logo/logo.png" alt="" /></a>
      </div>

      <div class="main-menu menu-hover">
        <nav>
          <ul>
            <li><a href="index.html">ACCUEIL</a></li>
            <li>
              <a href="#">TELECOMMUNICATION</a>
              <ul class="single-dropdown">
                <li>
                  <a href="#">Wifi</a>
                  <ul class="single-dropdown">
                    <li><a href="liaison_radio.html">Liaison radio</a></li>
                    <li><a href="bouclier_rf.html">Bouclier RF</a></li>
                    <li>
                      <a href="accessoire_faiwifi.html">Accessoire FAI WIFI</a>
                    </li>
                  </ul>
                </li>

                <li>
                  <a href="#">Fibre optique</a>
                  <ul class="single-dropdown">
                    <li><a href="gpon.html">GPON</a></li>
                    <li><a href="epon.html">EPON</a></li>
                    <li><a href="fusionneuse.html">Fusionneuse</a></li>
                    <li>
                      <a href="boite_d_f.html"
                        >Boiter de distribution de fibre</a
                      >
                    </li>
                    <li><a href="separateur.html">Separateurs</a></li>
                    <li><a href="cable.html">Cable</a></li>
                  </ul>
                </li>

                <li><a href="racks_externe.html">Racks exterieurs</a></li>

                <li><a href="panneaux.html">Panneaux</a></li>

                <li><a href="refrigelation.html">Refrigélation</a></li>

                <li><a href="plateaux.html">Plateaux</a></li>

                <li>
                  <a href="#">Outils</a>
                  <ul class="single-dropdown">
                    <li><a href="etiqueteuse.html">Etiqueteuse</a></li>
                    <li><a href="malette_outils.html">Malette à outil</a></li>
                    <li><a href="sertisseuse.html">Sertisseuses</a></li>
                  </ul>
                </li>
              </ul>
            </li>

            <li>
              <a href="#">RESEAUX</a>
              <ul class="single-dropdown">
                <li>
                  <a href="#">Ethernet</a>
                  <ul class="single-dropdown">
                    <li><a href="routeur.html">Routeurs</a></li>
                    <li><a href="fibre_optique.html">Fibre optique</a></li>
                    <li>
                      <a href="convertisseur.html">Convertisseur moyen</a>
                    </li>
                    <li>
                      <a href="adapteur_reseau.html">Adaptateur réseau</a>
                    </li>
                    <li>
                      <a href="accessoire_ethernet.html"
                        >Accessoires Ethernet</a
                      >
                    </li>
                    <li><a href="outil_ethernet.html">Outils Ethernet</a></li>
                  </ul>
                </li>

                <li>
                  <a href="#">Wifi</a>
                  <ul class="single-dropdown">
                    <li>
                      <a href="couverture_totale.html">couverture totale</a>
                    </li>
                    <li><a href="point_acces.html">Point d'accès</a></li>
                    <li><a href="controleur_ap.html">Contrleur AP</a></li>
                    <li><a href="repeteur.html">Repéteur</a></li>
                    <li><a href="adaptateur.html">Adaptateur</a></li>
                    <li><a href="routeur_r.html">Routeur</a></li>
                  </ul>
                </li>

                <li><a href="menu-list.html">Gestion</a></li>

                <li>
                  <a href="#">4G-LTE</a>
                  <ul class="single-dropdown">
                    <li><a href="routeur_4g.html">Routeur- 4G LTE</a></li>
                    <li><a href="rayon_ethernet.html">Rayon Ethernet</a></li>
                    <li><a href="cpe_ethernet.html">CPE Ethernet</a></li>
                    <li><a href="antenne.html">Antenne</a></li>
                  </ul>
                </li>
              </ul>
            </li>

            <li>
              <a href="#">SECURITE</a>
              <ul class="single-dropdown">
                <li>
                  <a href="paratonnere_parafoud.html">Paratonnere-parafoudre</a>
                </li>
              </ul>
            </li>

            <li>
              <a href="#">ELECTRICITE</a>
              <ul class="single-dropdown">
                <li><a href="courant_faible.html">Courant faible</a></li>
                <li><a href="paratonnere.html">Paratonnere/parafoudre</a></li>
              </ul>
            </li>

            <li>
                      <a href="#">TELEPHONE</a>
                      <ul class="single-dropdown">
                       <li>
                          <a href="#">Téléphone</a>
                          <ul class="single-dropdown">
                            <li>
                              <a href="téléphone_ip.html">Téléphone IP</a>
                            </li>
                            <li><a href="téléphone_vidéo.html">Téléphone vidéo IP</a></li>
                            <li>
                              <a href="téléphon_ip_dect.html"
                                >Téléphone IP dect </a
                              >
                            </li>
                          </ul>
                        </li>

                       <li>
                          <a href="#">Tableaux</a>
                          <ul class="single-dropdown">
                            <li>
                              <a href="petit_tablau.html">Pétit tableau</a>
                            </li>
                            <li><a href="module_pbx.html">Modules PBX</a></li>
                          </ul>
                        </li>
                          <a href="passerelle_ata.html">Paserelles ATA</a>
                    </li>

            <li>
              <a href="#">VIDEOSUEVEILLANCE</a>
              <ul class="single-dropdown">
                <li>
                  <a href="camera_surveillance.html">Caméra de surveillance</a>
                </li>
                <li><a href="camera_thermique.html">Caméra thermique</a></li>
                <li><a href="camera_ip.html">Caméra IP</a></li>
                <li>
                  <a href="#">Visioconférence</a>
                  <ul class="single-dropdown">
                    <li>
                      <a href="visioconference.html">Interphones vidéo</a>
                    </li>
                  </ul>
                </li>
              </ul>
            </li>

            <li>
              <a href="#">INFORMATIQUE</a>
              <ul class="single-dropdown">
                <li>
                  <a href="armoire_coffret_informatique.html"
                    >Armoire coffret informatique</a
                  >
                </li>
                <li><a href="ordinateur.html">Ordinateur</a></li>
              </ul>
            </li>

            <li><a href="about-us.html">SOCIETE</a></li>

            <li><a href="contact.html">CONTACT</a></li>
          </ul>
        </nav>
      </div>
    </div>
    <div class="header-right-sidebar">
      <div class="header-search-cart-login">
        <div class="logo">
          <a href="index.html">
            <img src="assets/img/logo/logo.png" alt="" />
          </a>
        </div>
        <div class="header-search">
          <form action="#">
            <input placeholder="Search What you want" type="text" />
            <button>
              <i class="ti-search"></i>
            </button>
          </form>
        </div>
        <div class="header-login">
          <ul>
            <li><a href="login.html">CONNEXION</a></li>
            <li><a href="register.html">S'INSCRIRE</a></li>
          </ul>
        </div>
        <div class="header-cart cart-res">
          <a class="icon-cart" href="cart.html">
            <i class="ti-shopping-cart"></i>
            <span class="shop-count pink">02</span>
          </a>
          <ul class="cart-dropdown">
            <li class="single-product-cart">
              <div class="cart-img">
                <a href="#"><img src="assets/img/cart/1.jpg" alt="" /></a>
              </div>
              <div class="cart-title">
                <h5><a href="#"> Bits Headphone</a></h5>
                <h6><a href="#">Black</a></h6>
                <span>$80.00 x 1</span>
              </div>
              <div class="cart-delete">
                <a href="#"><i class="ti-trash"></i></a>
              </div>
            </li>
            <li class="single-product-cart">
              <div class="cart-img">
                <a href="#"><img src="assets/img/cart/2.jpg" alt="" /></a>
              </div>
              <div class="cart-title">
                <h5><a href="#"> Bits Headphone</a></h5>
                <h6><a href="#">Black</a></h6>
                <span>$80.00 x 1</span>
              </div>
              <div class="cart-delete">
                <a href="#"><i class="ti-trash"></i></a>
              </div>
            </li>
            <li class="single-product-cart">
              <div class="cart-img">
                <a href="#"><img src="assets/img/cart/3.jpg" alt="" /></a>
              </div>
              <div class="cart-title">
                <h5><a href="#"> Bits Headphone</a></h5>
                <h6><a href="#">Black</a></h6>
                <span>$80.00 x 1</span>
              </div>
              <div class="cart-delete">
                <a href="#"><i class="ti-trash"></i></a>
              </div>
            </li>
            <li class="cart-space">
              <div class="cart-sub">
                <h4>Subtotal</h4>
              </div>
              <div class="cart-price">
                <h4>$240.00</h4>
              </div>
            </li>
            <li class="cart-btn-wrapper">
              <a class="cart-btn btn-hover" href="#">view cart</a>
              <a class="cart-btn btn-hover" href="#">checkout</a>
            </li>
          </ul>
        </div>
      </div>
      <div
        class="mobile-menu-area clearfix d-md-block col-md-12 col-lg-12 col-12 d-lg-none d-xl-none"
      >
        <div class="mobile-menu">
          <nav id="mobile-menu-active">
            <ul class="menu-overflow">
              <li><a href="index.html">ACCUEIL</a></li>
              <li>
                <a href="#">TELECOMMUNICATION</a>
                <ul class="single-dropdown">
                  <li>
                    <a href="#">Wifi</a>
                    <ul class="single-dropdown">
                      <li><a href="liaison_radio.html">Liaison radio</a></li>
                      <li><a href="bouclier_rf.html">Bouclier RF</a></li>
                      <li>
                        <a href="accessoire_faiwifi.html"
                          >Accessoire FAI WIFI</a
                        >
                      </li>
                    </ul>
                  </li>

                  <li>
                    <a href="#">Fibre optique</a>
                    <ul class="single-dropdown">
                      <li><a href="gpon.html">GPON</a></li>
                      <li><a href="epon.html">EPON</a></li>
                      <li><a href="fusionneuse.html">Fusionneuse</a></li>
                      <li>
                        <a href="boite_d_f.html"
                          >Boiter de distribution de fibre</a
                        >
                      </li>
                      <li><a href="separateur.html">Separateurs</a></li>
                      <li><a href="cable.html">Cable</a></li>
                    </ul>
                  </li>

                  <li><a href="racks_externe.html">Racks exterieurs</a></li>

                  <li><a href="panneaux.html">Panneaux</a></li>

                  <li><a href="refrigelation.html">Refrigélation</a></li>

                  <li><a href="plateaux.html">Plateaux</a></li>

                  <li>
                    <a href="#">Outils</a>
                    <ul class="single-dropdown">
                      <li><a href="etiqueteuse.html">Etiqueteuse</a></li>
                      <li><a href="malette_outils.html">Malette à outil</a></li>
                      <li><a href="sertisseuse.html">Sertisseuses</a></li>
                    </ul>
                  </li>
                </ul>
              </li>

              <li>
                <a href="#">RESEAUX</a>
                <ul class="single-dropdown">
                  <li>
                    <a href="#">Ethernet</a>
                    <ul class="single-dropdown">
                      <li><a href="routeur.html">Routeurs</a></li>
                      <li><a href="fibre_optique.html">Fibre optique</a></li>
                      <li>
                        <a href="convertisseur.html">Convertisseur moyen</a>
                      </li>
                      <li>
                        <a href="adapteur_reseau.html">Adaptateur réseau</a>
                      </li>
                      <li>
                        <a href="accessoire_ethernet.html"
                          >Accessoires Ethernet</a
                        >
                      </li>
                      <li><a href="outil_ethernet.html">Outils Ethernet</a></li>
                    </ul>
                  </li>

                  <li>
                    <a href="#">Wifi</a>
                    <ul class="single-dropdown">
                      <li>
                        <a href="couverture_totale.html">couverture totale</a>
                      </li>
                      <li><a href="point_acces.html">Point d'accès</a></li>
                      <li><a href="controleur_ap.html">Contrleur AP</a></li>
                      <li><a href="repeteur.html">Repéteur</a></li>
                      <li><a href="adaptateur.html">Adaptateur</a></li>
                      <li><a href="routeur_r.html">Routeur</a></li>
                    </ul>
                  </li>

                  <li><a href="menu-list.html">Gestion</a></li>

                  <li>
                    <a href="#">4G-LTE</a>
                    <ul class="single-dropdown">
                      <li><a href="routeur_4g.html">Routeur- 4G LTE</a></li>
                      <li><a href="rayon_ethernet.html">Rayon Ethernet</a></li>
                      <li><a href="cpe_ethernet.html">CPE Ethernet</a></li>
                      <li><a href="antenne.html">Antenne</a></li>
                    </ul>
                  </li>
                </ul>
              </li>

              <li>
                <a href="#">SECURITE</a>
                <ul class="single-dropdown">
                  <li>
                    <a href="paratonnere_parafoud.html"
                      >Paratonnere-parafoudre</a
                    >
                  </li>
                </ul>
              </li>

              <li>
                <a href="#">ELECTRICITE</a>
                <ul class="single-dropdown">
                  <li><a href="courant_faible.html">Courant faible</a></li>
                  <li><a href="paratonnere.html">Paratonnere/parafoudre</a></li>
                </ul>
              </li>

              <li>
                <a href="#">TELEPHONE</a>
                <ul class="single-dropdown">
                  <li><a href="telephone.html">Téléphone</a></li>
                  <li><a href="tablette.html">Tablette</a></li>
                  <li><a href="passerelle_ata.html">Paserelles ATA</a></li>
                </ul>
              </li>

              <li>
                <a href="#">VIDEOSUEVEILLANCE</a>
                <ul class="single-dropdown">
                  <li>
                    <a href="camera_surveillance.html"
                      >Caméra de surveillance</a
                    >
                  </li>
                  <li><a href="camera_thermique.html">Caméra thermique</a></li>
                  <li><a href="camera_ip.html">Caméra IP</a></li>
                  <li>
                    <a href="#">Visioconférence</a>
                    <ul class="single-dropdown">
                      <li>
                        <a href="visioconference.html">Interphones vidéo</a>
                      </li>
                    </ul>
                  </li>
                </ul>
              </li>

              <li>
                <a href="#">INFORMATIQUE</a>
                <ul class="single-dropdown">
                  <li>
                    <a href="armoire_coffret_informatique.html"
                      >Armoire coffret informatique</a
                    >
                  </li>
                  <li><a href="ordinateur.html">Ordinateur</a></li>
                </ul>
              </li>

              <li><a href="about-us.html">SOCIETE</a></li>

              <li><a href="contact.html">CONTACT</a></li>
            </ul>
          </nav>
        </div>
      </div>

      <div class="slider-area">
        <div class="slider-active owl-carousel">
          <div
            class="single-slider single-slider-hm1 bg-img height-100vh"
            style="background-image: url(assets/img/slider/15.jpg)"
          >
            <div
              class="slider-content slider-animation slider-content-style-1 slider-animated-1"
            >
              <h1 class="animated">Fashion</h1>
              <p class="animated">Create you own style for better looks.</p>
            </div>
            <div class="position-slider-img">
              <div class="slider-img-1">
                <img src="assets/img/slider/9.png" alt="" />
              </div>
              <div class="slider-img-2">
                <img class="tilter" src="assets/img/slider/7.png" alt="" />
              </div>
              <div class="slider-img-3">
                <img src="assets/img/slider/8.png" alt="" />
              </div>
            </div>
          </div>
          <div
            class="single-slider single-slider-hm1 bg-img height-100vh"
            style="background-image: url(assets/img/slider/15.jpg)"
          >
            <div
              class="slider-content slider-animation slider-content-style-1 slider-animated-2"
            >
              <h1 class="animated">Fashion</h1>
              <p class="animated">Create you own style for better looks.</p>
            </div>
            <div class="position-slider-img">
              <div class="slider-img-1">
                <img src="assets/img/slider/9.png" alt="" />
              </div>
              <div class="slider-img-4 slider-mrg">
                <img class="tilter" src="assets/img/slider/10.png" alt="" />
              </div>
              <div class="slider-img-3">
                <img src="assets/img/slider/8.png" alt="" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>
